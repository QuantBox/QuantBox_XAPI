#include "crypto_verify_16.h"

size_t
crypto_verify_16_bytes(void) {
    return crypto_verify_16_BYTES;
}
